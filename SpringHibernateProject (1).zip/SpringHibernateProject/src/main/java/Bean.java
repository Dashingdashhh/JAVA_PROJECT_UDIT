
public class Bean {

}
