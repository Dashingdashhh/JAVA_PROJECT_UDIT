package com.example.hibernatecrud;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class MainCRUD {

    public static void main(String[] args) {
        Session session = null;
        Transaction tx = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();

            // CREATE
            tx = session.beginTransaction();
            StudentEntity student = new StudentEntity("Madhvi", "Spring and Hibernate");
            session.persist(student);
            tx.commit();
            System.out.println("Student saved successfully!");

            // READ
            session = HibernateUtil.getSessionFactory().openSession();
            StudentEntity fetchedStudent = session.get(StudentEntity.class, student.getId());
            System.out.println(" Fetched Student: " + fetchedStudent);

            // UPDATE
            tx = session.beginTransaction();
            fetchedStudent.setCourse("Advanced Hibernate");
            session.merge(fetchedStudent);
            tx.commit();
            System.out.println(" Student updated successfully!");

            // DELETE
            tx = session.beginTransaction();
            session.remove(fetchedStudent);
            tx.commit();
            System.out.println(" Student deleted successfully!");

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            if (session != null) session.close();
            HibernateUtil.shutdown();
        }
    }
}
