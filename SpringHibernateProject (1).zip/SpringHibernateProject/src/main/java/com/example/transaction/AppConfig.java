package com.example.transaction;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.orm.hibernate5.HibernateTransactionManager;

@Configuration
@EnableTransactionManagement
public class AppConfig {

    @Bean
    public AccountDAO accountDAO() {
        return new AccountDAO();
    }

    @Bean
    public AccountService accountService() {
        AccountService service = new AccountService();
        service.setAccountDAO(accountDAO());
        return service;
    }

    @Bean
    public HibernateTransactionManager transactionManager() {
        return new HibernateTransactionManager(HibernateUtil.getSessionFactory());
    }
}
