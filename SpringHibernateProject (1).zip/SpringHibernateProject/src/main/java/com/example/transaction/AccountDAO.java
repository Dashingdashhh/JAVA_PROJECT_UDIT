package com.example.transaction;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class AccountDAO {

    public void saveAccount(Account account) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.persist(account);
        tx.commit();
        session.close();
    }

    public Account getAccount(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Account acc = session.get(Account.class, id);
        session.close();
        return acc;
    }

    public void updateAccount(Account account) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.merge(account);
        tx.commit();
        session.close();
    }
}
