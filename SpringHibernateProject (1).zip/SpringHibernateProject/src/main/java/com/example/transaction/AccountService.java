package com.example.transaction;

import org.springframework.transaction.annotation.Transactional;

public class AccountService {

    private AccountDAO accountDAO;

    public void setAccountDAO(AccountDAO accountDAO) {
        this.accountDAO = accountDAO;
    }

    @Transactional
    public void transferMoney(int fromId, int toId, double amount) {
        Account fromAcc = accountDAO.getAccount(fromId);
        Account toAcc = accountDAO.getAccount(toId);

        if (fromAcc == null || toAcc == null) {
            throw new RuntimeException("❌ One or both accounts not found!");
        }

        if (fromAcc.getBalance() < amount) {
            throw new RuntimeException("❌ Insufficient balance in " + fromAcc.getName());
        }

        fromAcc.setBalance(fromAcc.getBalance() - amount);
        toAcc.setBalance(toAcc.getBalance() + amount);

        accountDAO.updateAccount(fromAcc);
        accountDAO.updateAccount(toAcc);

        System.out.println("Transfer successful! ₹" + amount + " transferred from " + fromAcc.getName() + " to " + toAcc.getName());
    }
}
