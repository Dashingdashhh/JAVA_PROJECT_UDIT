package com.example.transaction;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TransactionMain {
    public static void main(String[] args) {

        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(AppConfig.class);

        AccountDAO dao = context.getBean(AccountDAO.class);
        AccountService service = context.getBean(AccountService.class);

        // ✅ Create two accounts
        dao.saveAccount(new Account("Madhvi", 8000.0));
        dao.saveAccount(new Account("Riya", 4000.0));

        System.out.println("💰 Initial Balances:");
        System.out.println(dao.getAccount(1));
        System.out.println(dao.getAccount(2));

        try {
            // ✅ Transfer ₹2000 from Madhvi to Riya
            service.transferMoney(1, 2, 2000.0);
        } catch (Exception e) {
            System.out.println("Transaction Failed: " + e.getMessage());
        }

        System.out.println("\n🏦 Updated Balances:");
        System.out.println(dao.getAccount(1));
        System.out.println(dao.getAccount(2));

        context.close();
        HibernateUtil.shutdown();
    }
}
