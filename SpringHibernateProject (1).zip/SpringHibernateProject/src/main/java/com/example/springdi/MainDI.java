package com.example.springdi;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainDI {
    public static void main(String[] args) {

        // Create Spring container using Java configuration
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(AppConfig.class);

        // Get the Student bean from Spring container
        Student student = context.getBean(Student.class);

        // Call method to test dependency injection
        student.showInfo();

        context.close();
    }
}
