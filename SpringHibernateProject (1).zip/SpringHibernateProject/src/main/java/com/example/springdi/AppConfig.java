package com.example.springdi;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public Course course() {
        return new Course("Spring and Hibernate");
    }

    @Bean
    public Student student() {
        // Spring will inject the Course bean here
        return new Student(course());
    }
}
